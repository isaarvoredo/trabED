#define MAXPILHA 10

struct TpPilhaM2 {
    int BASES[3];       // Bases das tr�s pilhas
    int TOPOS[3];       // Topos das tr�s pilhas
    int Pilha[MAXPILHA]; // Array compartilhado para as tr�s pilhas
};

// Inicializa as pilhas m�ltiplas
void Inicializar(TpPilhaM2 &PM, int numDiscos) {
    int i;
    for (i = 0; i < 3; i++) {
        PM.BASES[i] = (MAXPILHA / 3) * i; // Define a base de cada pilha (igual para 3, 5 ou 10 discos)
        PM.TOPOS[i] = PM.BASES[i] - 1;    // Inicializa o topo logo abaixo da base
    }
}


// Insere um elemento na pilha especificada
void PUSH(TpPilhaM2 &PM, int elem, int nPilha) {
    if (PM.TOPOS[nPilha] < MAXPILHA - 1) {
        PM.Pilha[++PM.TOPOS[nPilha]] = elem;
    } else {
        printf("Erro: Pilha %d cheia!\n", nPilha);
    }
}

// Remove e retorna o elemento do topo da pilha especificada
int POP(TpPilhaM2 &PM, int nPilha) {
    if (PM.TOPOS[nPilha] >= PM.BASES[nPilha]) {
        return PM.Pilha[PM.TOPOS[nPilha]--];
    } else {
        printf("Erro: Pilha %d vazia!\n", nPilha);
        return -1;
    }
}

// Retorna o elemento no topo da pilha sem remov�-lo
int ElementoTopo(TpPilhaM2 PM, int nPilha) {
    if (PM.TOPOS[nPilha] >= PM.BASES[nPilha]) {
        return PM.Pilha[PM.TOPOS[nPilha]];
    }
    return -1;
}

// Verifica se a pilha est� vazia
int Vazia(TpPilhaM2 PM, int nPilha) {
    return PM.TOPOS[nPilha] < PM.BASES[nPilha];
}

// Exibe os elementos da pilha especificada
void Exibir(TpPilhaM2 PM, int nPilha) {
    for (int i = PM.BASES[nPilha]; i <= PM.TOPOS[nPilha]; i++) {
        printf("%d ", PM.Pilha[i]);
    }
    printf("\n");
}

