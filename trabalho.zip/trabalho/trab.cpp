//TRABALHO ED1 - PILHAS MULTIPLHAS CASO N PILHAS

#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <ctype.h>
#include <conio.h>
#include <conio2.h>


#include "tad_trab.h"

void FundoMoldura(int CI, int LI, int CF, int LF, int cor)
{
	int col,lin;
	for(lin=LI+1; lin<LF; lin++)
		for(col=CI+1; col<CF; col++)
		{
			textcolor(cor);
			gotoxy(col,lin);
			printf("%c",177);
		}
}
		
void Moldura(int CI, int LI, int CF, int LF, int cor)
{
	int i;
	
	//FundoMoldura(CI,LI,CF,LF,cor);
	textcolor(cor);
	gotoxy(CI,LI);
	printf("%c",201);
	gotoxy(CF,LI);
	printf("%c",187);
	gotoxy(CI,LF);
	printf("%c",200);
	gotoxy(CF,LF);
	printf("%c",188);
	for(i=CI+1;i<CF;i++)
	{
		gotoxy(i,LI);
		printf("%c",205);
		gotoxy(i,LF);
		printf("%c",205);
	}
	for(i=LI+1;i<LF;i++)
	{
		gotoxy(CI,i);
		printf("%c",186);
		gotoxy(CF,i);
		printf("%c",186);
	}
	textcolor(7);
}

void MoldPrincipal(void)
{
	Moldura(1,1,120,30,11);
	Moldura(3,2,110,4,10);
	gotoxy(43,3);
	textcolor(6);
	printf("***  SISTEMA DE TORRES HANOI  ***");
	textcolor(WHITE);
	Moldura(3,5,110,26,8);
	Moldura(3,27,110,29,9);
	gotoxy(5,28);
	printf("Mensagem:                                                                ");
	gotoxy(15,28);
}


void ExibirComInterface(TpPilhaM2 PM, int nPilha, int x, int y, int numDiscos) {
    int i, j = y + numDiscos - 1;

    gotoxy(x, y);
    printf("|   |\n");
    for (i = PM.BASES[nPilha]; i <= PM.TOPOS[nPilha]; i++) {
        gotoxy(x, j--);
        printf("| %d |\n", PM.Pilha[i]);
    }
    while (j >= y) {
        gotoxy(x, j--);
        printf("|   |\n");
    }
}

void SimulacaoAutomatica(TpPilhaM2 &PM, int numDiscos) {
    int movimento = 0;
    clrscr();
    MoldPrincipal();
    while (PM.TOPOS[2] != PM.BASES[2] + numDiscos - 1) {
        movimento++;
        if (movimento % 3 == 1) {
            if (Vazia(PM, 0) || (!Vazia(PM, 2) && ElementoTopo(PM, 2) < ElementoTopo(PM, 0))) {
                int disco = POP(PM, 2);
                PUSH(PM, disco, 0);
            } else {
                int disco = POP(PM, 0);
                PUSH(PM, disco, 2);
            }
        } else if (movimento % 3 == 2) {
            if (Vazia(PM, 0) || (!Vazia(PM, 1) && ElementoTopo(PM, 1) < ElementoTopo(PM, 0))) {
                int disco = POP(PM, 1);
                PUSH(PM, disco, 0);
            } else {
                int disco = POP(PM, 0);
                PUSH(PM, disco, 1);
            }
        } else if (movimento % 3 == 0) {
            if (Vazia(PM, 1) || (!Vazia(PM, 2) && ElementoTopo(PM, 2) < ElementoTopo(PM, 1))) {
                int disco = POP(PM, 2);
                PUSH(PM, disco, 1);
            } else {
                int disco = POP(PM, 1);
                PUSH(PM, disco, 2);
            }
        }

        system("cls");
        ExibirComInterface(PM, 0, 10, 5, numDiscos);
        ExibirComInterface(PM, 1, 30, 5, numDiscos);
        ExibirComInterface(PM, 2, 50, 5, numDiscos);
        printf("\n");
        Sleep(500);
    }
}

void SimulacaoManual(TpPilhaM2 &PM, int numDiscos) {
    int origem, destino;
    while (PM.TOPOS[2] != PM.BASES[2] + numDiscos - 1) {
        clrscr();
        MoldPrincipal();
        gotoxy(5, 18);
        printf("Estado atual das pilhas:\n");
        ExibirComInterface(PM, 0, 10, 5, numDiscos);
        ExibirComInterface(PM, 1, 30, 5, numDiscos);
        ExibirComInterface(PM, 2, 50, 5, numDiscos);
        printf("\n");
        gotoxy(5, 19);
        printf("Escolha a pilha de origem (0 = A, 1 = B, 2 = C): ");
        gotoxy(15, 28);
        scanf("%d", &origem);
        gotoxy(5, 20);
        printf("Escolha a pilha de destino (0 = A, 1 = B, 2 = C): ");
        gotoxy(15, 28);
        scanf("%d", &destino);

        if (origem < 0 || origem > 2 || destino < 0 || destino > 2) {
            gotoxy(15, 28);
            printf("Erro: Pilha inv�lida.\n");
            continue;
        }

        if (Vazia(PM, origem)) {
            gotoxy(15, 21);
            printf("Erro: Pilha de origem est� vazia.\n");
            continue;
        }

        if (!Vazia(PM, destino) && ElementoTopo(PM, origem) > ElementoTopo(PM, destino)) {
            gotoxy(15, 21);
            printf("Erro: N�o � permitido mover um disco maior sobre um menor.\n");
            continue;
        }

        int disco = POP(PM, origem);
        PUSH(PM, disco, destino);
    }
    gotoxy(15, 22);
    textcolor(5);
    printf("Parab�ns! Voc� completou a Torre de Han�i com sucesso!\n");
    gotoxy(15, 23);
    printf("Estado final das pilhas:\n");
    ExibirComInterface(PM, 0, 10, 5, numDiscos);
    ExibirComInterface(PM, 1, 30, 5, numDiscos);
    ExibirComInterface(PM, 2, 50, 5, numDiscos);
}

// Fun��o principal
int main() {
    TpPilhaM2 PM;
    int numDiscos, escolha;
    MoldPrincipal();
    gotoxy(5,7);
    printf("Escolha o numero de discos (3 a 10): ");
    gotoxy(15,28);
    scanf("%d", &numDiscos);

    if (numDiscos < 3 || numDiscos > 10) {
        printf("Erro: Numero de discos invalido. Escolha entre 3 e 10.\n");
        return 1;
    }

    Inicializar(PM, 3);

    // Empilhar os discos na pilha A (do maior para o menor)
    for (int i = numDiscos; i >= 1; i--) {
        PUSH(PM, i, 0);
    }
	
	clrscr();
	MoldPrincipal();
	gotoxy(5,6);
	textcolor(7);
	gotoxy(5,8);
    printf("Escolha o modo de simulacao:\n");
    gotoxy(5,9);
    printf("1 - Simulacao Automatica\n");
    gotoxy(5,10);
    printf("2 - Simulacao Manual\n");
    gotoxy(5,11);
    printf("Digite sua escolha: ");
    gotoxy(15,28);
    scanf("%d", &escolha);

    if (escolha == 1) {
        SimulacaoAutomatica(PM, numDiscos);
    } else if (escolha == 2) {
        SimulacaoManual(PM, numDiscos);
    } else {
    	//clrscr();
//		MoldPrincipal(); n ta dando certo
    	gotoxy(15,28);
        printf("Op�ao invalida. Encerrando o programa.\n"); //so tava morrendo entao coloquei pra encerrar
        return 1;
    }

    return 0;
}
